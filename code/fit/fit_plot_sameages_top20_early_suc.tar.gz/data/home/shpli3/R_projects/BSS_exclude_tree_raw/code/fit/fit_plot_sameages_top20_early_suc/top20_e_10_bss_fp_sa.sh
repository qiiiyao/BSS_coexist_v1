#!/bin/sh -x
#PBS -l nodes=1:ppn=20
#PBS -N mytask3
#PBS -l walltime=30000:00:00       
#PBS -o stdout_file
#PBS -e stderr_file
#PBS -m abe
#PBS -M 1294794885@qq.com

cd $PBS_O_WORKDIR
date
hostname
/data/apps/R-4.2.2/lib64/R/bin/R CMD BATCH  /data/home/shpli3/R_projects/BSS_exclude_tree_raw/code/fit/fit_plot_sameages_top20_early_suc/fit_plot_alltime_10.R /data/home/shpli3/R_projects/BSS_exclude_tree_raw/code/fit/fit_plot_sameages_top20_early_suc/fit_plot_alltime_10.Rout
date
