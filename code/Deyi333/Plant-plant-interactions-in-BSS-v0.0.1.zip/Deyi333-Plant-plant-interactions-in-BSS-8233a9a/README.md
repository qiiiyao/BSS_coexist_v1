# Plant-plant-interactions-in-BSS
Codes that used to analyze the plant-plant interactions in BSS plots have been archived here.
The first code script, data sorting.R can be used to select species (25 natives and 25 exotics) and change the orginal data into the format we need in the following statisitcal models.
The second code script, occurrence-bayesian.R contains the codes of hierarchical models to evaluate the effects of neighboring species covers on species occurrence, survival, colonization and population growth rate.

Please contact yindeyi@scbg.ac.cn if you have any problem when using these codes.
